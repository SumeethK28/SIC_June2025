# Hackathon_Car_Wash_App
Hackathon conducted after successful completion of Samsung Innovation Campus Training, where I got an opportunity to learn Python Fundamentals, OOPS, DSA and Data Analytics. At the end of the Training, I created a Car Wash App based on the topics which I learnt. 

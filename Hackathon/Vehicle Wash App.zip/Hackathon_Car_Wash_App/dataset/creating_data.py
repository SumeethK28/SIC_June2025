import numpy as np
import pandas as pd
from datetime import datetime, timedelta
# from tabulate import tabulate  # Module to display data in table format

number_of_data = 800   # Setting data Limit.
services = ['Bike', 'Interior Car Wash', 'Exterior Car Wash', 'Both Interior and Exterior']
customer_id = [f"C{100 + i}" for i in range(1, 101)]
base_date = datetime(2024, 1, 1, 6, 0, 0)   # Starts from 1st Jan 2024.

data = []   # Creating an empty list and then inserting random data.

for i in range(1, number_of_data + 1):
    cust_id = np.random.choice(customer_id)
    service = np.random.choice(services)

    date = base_date + timedelta(days = np.random.randint(0, 240), hours = np.random.randint(0, 14), minutes = np.random.randint(0, 61), seconds = np.random.randint(0,61))   # For a period of 8 months.

    amount = {
        'Bike': 200,
        'Interior Car Wash': 500,
        'Exterior Car Wash': 500,
        'Both Interior and Exterior': 800
    }[service]

    data.append([i, cust_id, service, date.strftime("%Y-%m-%d %H:%M:%S"), amount])   # In what format the data should be.

df = pd.DataFrame(data, columns = ['SL No.', 'Cutomer ID', 'services', 'Date & Time', 'Amount (In ₹)'])   # Converting list to dataFrame along with Headings.

df.to_csv("./car_wash_csv", index = False)   # Then finally converting the dataFrame to csv file.

# If want to display in table format
# print(tabulate(df, headers = ['ID', 'Cutomer ID', 'services', 'Date', 'Amount'], tablefmt = "rounded_grid", showindex = False, missingval = "N/A",numalign = "center", stralign = "center"))
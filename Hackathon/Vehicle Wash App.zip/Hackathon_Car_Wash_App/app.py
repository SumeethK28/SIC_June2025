from flask import Flask, render_template
from services.analysis import Analysis

app = Flask(__name__)

filepath = 'D:\Learning\Hackathon_Car_Wash_App\dataset\car_wash_csv'
analyzer = Analysis(filepath)

@app.route('/')
def sales_distribution():
    sales = analyzer.sales_distribution()
    plot_data = analyzer.high_demand_months()
    holiday = analyzer.festival_sales_comparison()
    cust = analyzer.customer_growth_trend()
    vip = analyzer.top_customers_vip()

    return render_template('index.html', sales=sales, plot_data=plot_data, holiday = holiday, cust = cust, vip = vip)

if __name__ == '__main__':
    app.run(debug=True)
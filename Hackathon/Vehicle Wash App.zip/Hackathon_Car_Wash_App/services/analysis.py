import pandas as pd
from io import BytesIO
import matplotlib.pyplot as plt
import base64

class Analysis:
    def __init__(self, filepath):
        self.filepath = filepath

    def sales_distribution(self):
        df = pd.read_csv(self.filepath)

        sales = df.groupby('services')['Amount (In ₹)'].sum()

        plt.figure(figsize = (12,6))
        sales.plot(kind = 'bar', color = 'skyblue')
        plt.title('Sales Distribution')
        plt.xlabel('Months')
        plt.ylabel('Sales')
        plt.legend()
        plt.xticks(rotation = 0, ha = 'center', fontsize = 10)
        
        img_bytes = BytesIO()
        plt.savefig(img_bytes, format = 'png', bbox_inches='tight')
        plt.close()

        return base64.b64encode(img_bytes.getvalue()).decode('utf-8')

    def high_demand_months(self):
        df = pd.read_csv(self.filepath)

        df['Date & Time'] = pd.to_datetime(df['Date & Time'])
        df['Month'] = df['Date & Time'].dt.month_name()
        
        # Get monthly totals and sort properly
        month_order = ['January', 'February', 'March', 'April', 'May', 'June',
                    'July', 'August', 'September', 'October', 'November', 'December']
        monthly_demand = df.groupby('Month')['Amount (In ₹)'].sum().reindex(month_order)
        
        # Simple plot with your original style
        plt.figure(figsize=(12,6))
        monthly_demand.plot(kind='line', color='skyblue', linewidth=4)
        
        plt.title('High Demand Months')
        plt.xlabel('Months')
        plt.ylabel('Total Revenue (₹)')
        plt.xticks(rotation=0)  # Horizontal labels
        
        img_bytes = BytesIO()
        plt.savefig(img_bytes, format = 'png', bbox_inches='tight')
        plt.close()

        return base64.b64encode(img_bytes.getvalue()).decode('utf-8')

    def festival_sales_comparison(self):
        df = pd.read_csv(self.filepath)
        df['Date & Time'] = pd.to_datetime(df['Date & Time'])

        # List of 6 major Indian festivals in 2024 (date format: YYYY-MM-DD)
        festivals = {
            'Makar Sankranti': '2024-01-15',
            'Holi': '2024-03-25',
            'Ugadi': '2024-04-09',
            'Raksha Bandhan': '2024-08-19',
            'Ganesh Chaturthi': '2024-09-07',
            'Diwali': '2024-11-01'
        }
        festival_dates = pd.to_datetime(list(festivals.values()))
        festival_eve_dates = festival_dates - pd.Timedelta(days=1)

        # Mark festival and eve days
        df['Festival Day'] = df['Date & Time'].dt.date.isin(festival_dates.date) | df['Date & Time'].dt.date.isin(festival_eve_dates.date)

        # Apply 50% price increase for festival/eve days
        df['Adjusted Amount'] = df.apply(
            lambda row: row['Amount (In ₹)'] * 1.50 if row['Festival Day'] else row['Amount (In ₹)'],
            axis=1
        )

       # Mark festival and eve days
        df['Festival Day'] = df['Date & Time'].dt.date.isin(festival_dates.date) | df['Date & Time'].dt.date.isin(festival_eve_dates.date)

        # Apply 50% price increase for festival/eve days
        df['Adjusted Amount'] = df.apply(
            lambda row: row['Amount (In ₹)'] * 1.50 if row['Festival Day'] else row['Amount (In ₹)'],
            axis=1
        )

        # Filter only festival/eve days
        festival_df = df[df['Festival Day']]

        # Group by service and sum adjusted amount
        service_sales = festival_df.groupby('services')['Adjusted Amount'].sum()

        print(service_sales)

        plt.figure(figsize=(10,6))
        service_sales.plot(kind='bar', color='orange')
        plt.title('Festival Sales by Service')
        plt.xlabel('Service')
        plt.ylabel('Total Revenue (₹)')
        plt.xticks(rotation=0, ha='center', fontsize=10)

        img_bytes = BytesIO()
        plt.savefig(img_bytes, format='png', bbox_inches='tight')
        plt.close()

        return base64.b64encode(img_bytes.getvalue()).decode('utf-8')
    
    def customer_growth_trend(self):
        df = pd.read_csv(self.filepath)
        df['Date & Time'] = pd.to_datetime(df['Date & Time'])
        df['Month'] = df['Date & Time'].dt.month_name()
        df['Month_Num'] = df['Date & Time'].dt.month

        # Sort by date for correct tracking
        df = df.sort_values('Date & Time')

        # Track new customers month by month
        seen_customers = set()
        growth = {}

        # Get months in order
        months_order = df[['Month_Num', 'Month']].drop_duplicates().sort_values('Month_Num')
        for month_num, month_name in zip(months_order['Month_Num'], months_order['Month']):
            month_df = df[df['Month_Num'] == month_num]
            new_customers = set(month_df['Cutomer ID']) - seen_customers
            growth[month_name] = len(new_customers)
            seen_customers.update(new_customers)

        growth_series = pd.Series(growth)

        print(growth_series)

        plt.figure(figsize=(12,6))
        growth_series.plot(kind='pie', color='green')
        plt.title('Monthly New Customer Growth')
        plt.xlabel('Month')
        plt.ylabel('Number of New Customers')
        plt.xticks(rotation=0, ha='center', fontsize=10)
        plt.legend()

        img_bytes = BytesIO()
        plt.savefig(img_bytes, format='png', bbox_inches='tight')
        plt.close()

        return base64.b64encode(img_bytes.getvalue()).decode('utf-8')
    
    def top_customers_vip(self):
        df = pd.read_csv(self.filepath)
        # Group by customer and sum total spend
        customer_spend = df.groupby('Cutomer ID')['Amount (In ₹)'].sum().sort_values(ascending=False)
        top5 = customer_spend.head(5)

        print(top5)

        # Mark the top spender as VIP
        labels = [f"{cid} (VIP)" for cid in top5.index]

        plt.figure(figsize=(10,6))
        top5.plot(kind='bar', color=['gold']*5)
        plt.title('Top 5 Customers by Total Spend')
        plt.xlabel('Customer ID')
        plt.ylabel('Total Spend (₹)')
        plt.xticks(ticks=range(5), labels=labels, rotation=0, ha='center', fontsize=10)

        img_bytes = BytesIO()
        plt.savefig(img_bytes, format='png', bbox_inches='tight')
        plt.close()

        return base64.b64encode(img_bytes.getvalue()).decode('utf-8')